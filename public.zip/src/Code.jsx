import React from "react";
const Code = () => {
    return (
        <h1>dxzdsfsfvssfdsdd</h1>
    );

};
export default Code;